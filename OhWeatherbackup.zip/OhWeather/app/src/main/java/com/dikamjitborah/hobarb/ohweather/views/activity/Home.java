package com.dikamjitborah.hobarb.ohweather.views.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.dikamjitborah.hobarb.ohweather.R;

public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
}